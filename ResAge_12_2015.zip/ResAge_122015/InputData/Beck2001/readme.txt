Beck et al., Science 292, 2453 (2001) 
- only the data overlapping the IntCal13 master tree-ring dataset 
- identification numbers are from the IntCal13 database.