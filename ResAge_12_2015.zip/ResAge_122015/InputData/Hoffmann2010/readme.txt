Hoffmann et al., Earth and Planetary Science Letters, 289, 1�10, (2010) 
- only the data overlapping the IntCal13 master tree-ring dataset 
- identification numbers are from the IntCal13 database.