Southon et al., Quaternary Science Reviews 33, 31�41 (2012)
- only the data overlapping the IntCal13 master tree-ring dataset 